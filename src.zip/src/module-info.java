/**
 * 
 */
/**
 * 
 */
module project_software_engineering {
	requires java.desktop;
}